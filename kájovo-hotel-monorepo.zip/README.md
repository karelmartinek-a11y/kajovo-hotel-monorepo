# KájovoHotel monorepo

Tento repozitář je nový cílový monorepo pro refaktor:
- legacy/hotel-frontend
- legacy/hotel-backend

SSOT pravidla: `ManifestDesignKájovo.md`.

Primární cíle:
- apps/kajovo-hotel-web
- apps/kajovo-hotel-api
- packages/ui
- packages/shared
- apps/kajovo-hotel (tokeny/paleta/motion/IA dle manifestu)
