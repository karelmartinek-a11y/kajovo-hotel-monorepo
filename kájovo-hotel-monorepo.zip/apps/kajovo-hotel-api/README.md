# KájovoHotel API

Backend application skeleton. Will be migrated from legacy/hotel-backend.
