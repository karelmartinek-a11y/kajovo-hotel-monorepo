# KájovoHotel Web

Web application skeleton. UI must use @kajovo/ui and tokens in apps/kajovo-hotel.
