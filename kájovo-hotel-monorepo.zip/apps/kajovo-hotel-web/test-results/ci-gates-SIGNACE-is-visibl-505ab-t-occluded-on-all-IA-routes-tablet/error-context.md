# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - navigation "Hlavní navigace" [ref=e6]:
      - generic [ref=e8]:
        - generic [ref=e9]: Přehled
        - link "Přehled" [ref=e10]:
          - /url: /
        - generic [ref=e11]: Provoz
        - link "Snídaně" [ref=e12]:
          - /url: /snidane
        - link "Závady" [ref=e13]:
          - /url: /zavady
        - generic [ref=e14]: Evidence
        - link "Ztráty a nálezy" [ref=e15]:
          - /url: /ztraty-a-nalezy
        - button "Další" [ref=e17] [cursor=pointer]
  - main [ref=e18]:
    - generic [ref=e19]:
      - heading "Intro" [level=2] [ref=e20]
      - paragraph [ref=e21]: Úvodní obrazovka aplikace.
      - link "Pokračovat na dashboard" [ref=e23] [cursor=pointer]:
        - /url: /
  - link "KÁJOVO" [ref=e24]:
    - /url: /
```