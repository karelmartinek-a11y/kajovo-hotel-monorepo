# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - navigation "Hlavní navigace" [ref=e6]:
      - generic [ref=e8]:
        - generic [ref=e9]: Přehled
        - link "Přehled" [ref=e10] [cursor=pointer]:
          - /url: /
        - generic [ref=e11]: Provoz
        - link "Snídaně" [ref=e12] [cursor=pointer]:
          - /url: /snidane
        - link "Závady" [ref=e13] [cursor=pointer]:
          - /url: /zavady
        - generic [ref=e14]: Evidence
        - link "Ztráty a nálezy" [ref=e15] [cursor=pointer]:
          - /url: /ztraty-a-nalezy
        - link "Skladové hospodářství" [ref=e16] [cursor=pointer]:
          - /url: /sklad
        - link "Hlášení" [ref=e17] [cursor=pointer]:
          - /url: /hlaseni
  - main [ref=e18]:
    - generic [ref=e19]:
      - heading "404" [level=2] [ref=e20]
      - paragraph [ref=e21]: Stránka nebyla nalezena.
      - link "Zpět na hlavní stránku" [ref=e23] [cursor=pointer]:
        - /url: /
  - link "KÁJOVO" [ref=e24] [cursor=pointer]:
    - /url: /
```