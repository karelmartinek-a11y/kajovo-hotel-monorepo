# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - navigation "Hlavní navigace" [ref=e6]:
      - button "Menu" [ref=e8] [cursor=pointer]
  - main [ref=e9]:
    - generic [ref=e10]:
      - heading "404" [level=2] [ref=e11]
      - paragraph [ref=e12]: Stránka nebyla nalezena.
      - link "Zpět na hlavní stránku" [ref=e14] [cursor=pointer]:
        - /url: /
  - link "KÁJOVO" [ref=e15] [cursor=pointer]:
    - /url: /
```