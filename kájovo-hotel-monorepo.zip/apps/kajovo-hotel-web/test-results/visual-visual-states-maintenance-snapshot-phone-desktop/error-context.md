# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - navigation "Hlavní navigace" [ref=e6]:
      - button "Menu" [ref=e8] [cursor=pointer]
  - main [ref=e9]:
    - generic [ref=e10]:
      - heading "Maintenance" [level=2] [ref=e11]
      - paragraph [ref=e12]: Probíhá údržba systému. Sledujte status a zkuste to za chvíli znovu.
      - generic [ref=e13]:
        - link "Zpět na dashboard" [ref=e14] [cursor=pointer]:
          - /url: /
        - link "Diagnostika provozu" [ref=e15] [cursor=pointer]:
          - /url: /offline
  - link "KÁJOVO" [ref=e16] [cursor=pointer]:
    - /url: /
```