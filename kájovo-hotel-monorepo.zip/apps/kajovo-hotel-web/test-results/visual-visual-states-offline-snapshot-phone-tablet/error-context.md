# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - navigation "Hlavní navigace" [ref=e6]:
      - button "Menu" [ref=e8] [cursor=pointer]
  - main [ref=e9]:
    - generic [ref=e10]:
      - heading "Offline" [level=2] [ref=e11]
      - paragraph [ref=e12]: Aplikace je bez připojení. Zkontrolujte síť a zkuste synchronizaci znovu.
      - generic [ref=e13]:
        - button "Zkusit znovu" [ref=e14] [cursor=pointer]
        - link "Pracovat offline režimem" [ref=e15] [cursor=pointer]:
          - /url: /
  - link "KÁJOVO" [ref=e16]:
    - /url: /
```