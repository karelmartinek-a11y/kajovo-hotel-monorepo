# Brand assets

Tento adresář obsahuje app-level assety značky pro monorepo.

SSOT pravidla: `../../ManifestDesignKájovo.md`.
