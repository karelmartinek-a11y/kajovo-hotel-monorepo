﻿# Legacy sources (READ-ONLY)
Everything in /legacy is source material only.
All new work must go to /apps and /packages.
Never edit files under /legacy.
