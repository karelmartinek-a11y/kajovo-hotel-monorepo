#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NGINX_SITE_PATH="${NGINX_SITE_PATH:-/etc/nginx/conf.d/kajovohotel.conf}"
NGINX_TEST_CMD="${NGINX_TEST_CMD:-nginx -t}"
NGINX_RELOAD_CMD="${NGINX_RELOAD_CMD:-systemctl reload nginx}"

cp "$SCRIPT_DIR/production-legacy.conf" "$NGINX_SITE_PATH"
$NGINX_TEST_CMD
$NGINX_RELOAD_CMD

echo "Rolled back production hostname to LEGACY stack using $NGINX_SITE_PATH"
