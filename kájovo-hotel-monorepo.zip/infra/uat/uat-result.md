# UAT výsledek – kajovohotel-staging.hcasc.cz

Datum/čas startu: <doplnit>
Tester: <jméno>
Prostředí: staging
Verze aplikace: <release/sha>

## Odkazy
- UAT scénáře: docs/uat.md
- UAT test účty: docs/test-accounts.md

## Shrnutí
- Celkový výsledek: <PASS/FAIL>
- Blokující problémy: <ano/ne>
- Poznámka: <stručné shrnutí>

## Výsledky scénářů (vyplnit)
| Scénář | Výsledek | Poznámka |
|---|---|---|
| Přehled + utility stavy |  |  |
| Snídaně |  |  |
| Ztráty a nálezy |  |  |
| Závady |  |  |
| Sklad |  |  |
| Hlášení |  |  |
| Cross-module scénáře |  |  |

## Test zařízení
| Device | OK/FAIL | Poznámka |
|---|---|---|
| Telefon |  |  |
| Tablet |  |  |
| Desktop |  |  |

## Incidenty / blokery
- <popis>
