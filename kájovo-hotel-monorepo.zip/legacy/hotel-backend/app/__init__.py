"""KájovoHotel - backend package.

This project is intentionally self-hosted (no Firebase/Auth0/FCM/Play Integrity).
"""

__all__ = ["__version__"]

# Keep version here to show in health endpoints and admin footer.
__version__ = "1.0.0"
