# KájovoHotel – Brand Asset Kit

Zdroj pravdy: `master/KajovoHotel_clean_curves_fixed.svg` (přiložený master).

Vygenerované výstupy jsou v `assets/svg` (vektor) a `assets/png` (rastrové exporty) a ikony v `assets/icons`.

Poznámky:
- Všechny exporty jsou na průhledném pozadí, bez stínů / efektů / filtrů.
- Wordmark pro verze „dark“ je zesvětlen na bílou pro čitelnost, mark/signace zůstává beze změny.
- Ikony a favicony používají pouze „mark“ (erb se signací), s bezpečným paddingem (12 %) a optickým vycentrováním vychází z ořezu podle neprůhledných pixelů.
