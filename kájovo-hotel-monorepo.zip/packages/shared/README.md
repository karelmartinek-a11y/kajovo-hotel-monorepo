# @kajovo/shared

Shared types and (later) generated API client.
