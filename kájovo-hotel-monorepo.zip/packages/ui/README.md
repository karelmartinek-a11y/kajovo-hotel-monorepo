# @kajovo/ui

Design system pro KájovoHotel. Implementace používá tokeny z:
- `apps/kajovo-hotel/ui-tokens/tokens.json`
- `apps/kajovo-hotel/palette/palette.json`
- `apps/kajovo-hotel/ui-motion/motion.json`

SSOT pravidla: `ManifestDesignKájovo.md`.
